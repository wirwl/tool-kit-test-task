import { useState } from 'react';
import mainStyles from './index.module.scss';

const { inputSearch, buttonSearch } = mainStyles;

type Props = {
    onSearch: (text:string) => void;
}

export function SearchPanel({onSearch}:Props) {
    const [search, setSearch] = useState('');

    const handleQueryChange = (e) => setSearch(e.target.value);
    const handleInputKeyDown = (e) => {
        if (e.key === 'Enter' || e.keyCode === 13) {
            handleSearchClick();
        }
    }
    const handleSearchClick = async () => {        
        onSearch(search);
    }
   

    return <div>
        <input className={inputSearch} onChange={handleQueryChange} onKeyDown={handleInputKeyDown} />
        <button className={buttonSearch} onClick={handleSearchClick}>Искать</button>
    </div>
}