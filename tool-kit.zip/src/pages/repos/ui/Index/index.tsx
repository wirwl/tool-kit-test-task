import mainStyles from "./index.module.scss";
import { useEffect, useState } from "react";
import oa from 'oauthio-web';
import { useUnit } from "effector-react";
import { $token, saveToken } from "../../../../shared/stores/token";
import { getRepos } from "../../../../entities/common/lib/gql";
import { RepoItem } from "../../../../entities/repos/ui/RepoItem";
import { useLazyQuery, useQuery } from "@apollo/client";
import { Paginator } from "../../../../features/common/ui/Paginator";
import { RepoList } from "../../../../features/common/ui/RepoList";
import { SearchPanel } from "../../../../features/common/ui/SearchPanel";

// const OAuth = require('oauthio-web');

const { root, login, inputSearch, buttonSearch } = mainStyles;

export function Index() {
    const [token, setToken] = useUnit([$token, saveToken]);
    const [fetchRepos, { loading, error, data }] = useLazyQuery(getRepos);

    const handleSearchPanel = (query: string) => {
        fetchRepos({
            variables: {
                query
            }
        }
        );
    }

    console.log(error);
    useEffect(() => {

    }, []);

    const handleClickLogin = () => {
        oa.OAuth.initialize('HwAr2OtSxRgEEnO2-JnYjsuA3tc');

        oa.OAuth.popup('github').then((github: any) => {
            console.log('github:', github);
            console.log('github', github.toJson());
            setToken(github.access_token);
            github.me().then((data: any) => {
                console.log('me data:', data);
            });
            // github.get('/user').then(data => {
            //     console.log('self data:', data);
            // })
        });
    }

    return <div className={root}>
        <header>
            <button className={login} onClick={handleClickLogin}>
                {token ? 'Выйти' : 'Войти на Github'}
            </button>
        </header>
        <main>
            <SearchPanel onSearch={handleSearchPanel} />
            <RepoList repos={data && data.search.repos} />
        </main>
    </div>
}
